import express from 'express';
import cors from 'cors';

const app=express();
app.use(cors());
app.use(express.json({limit:'256kb'}));

function offline(message,context){
  const q=String(message||'').toLowerCase();
  if(q.includes('ریاضی')||q.includes('math')) return 'برای ریاضی: مفهوم را توضیح بده، یک مثال را بدون نگاه دوباره حل کن، ۳ تا ۵ سؤال مشابه بزن و اشتباهاتت را ثبت کن.';
  if(q.includes('پیک')||q.includes('alternate')) return 'برای alternate picking از مترونوم استفاده کن و تمیزی را قبل از سرعت نگه دار. تمرین ۱۰ دقیقه گرم‌کردن + تمرین تکنیک + یک بخش آهنگ انجام بده.';
  if(q.includes('امروز')||q.includes('today')) return 'بر اساس context ارسالی، کارهای باقی‌مانده را بررسی کن و فقط یک تا دو کار اصلی را جلو بینداز؛ زمان استراحت را هم حفظ کن.';
  return 'پاسخ نمونهٔ backend: برای این سؤال می‌توان context برنامه و پیشرفت را به سرویس AI واقعی فرستاد. این فایل عمداً API key را در کلاینت قرار نمی‌دهد.';
}

app.post('/chat',async(req,res)=>{
  const {message,context}=req.body||{};
  // Replace this section with your provider SDK/API call on the server.
  // Read the provider API key from an environment variable, never from the browser.
  res.json({response:offline(message,context||{})});
});

app.get('/health',(_,res)=>res.json({ok:true}));
const port=process.env.PORT||8787;
app.listen(port,()=>console.log(`Artiman AI backend listening on ${port}`));
