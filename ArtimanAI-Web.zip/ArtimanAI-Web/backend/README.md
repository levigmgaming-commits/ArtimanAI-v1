# Secure backend example

This is a minimal Node/Express backend. It intentionally does **not** include a real AI provider key.

## Run
```bash
npm install
PORT=8787 node server.js
```

## Add a real AI provider
Implement the provider call inside `POST /chat` and read the API key from an environment variable, for example:
```bash
export AI_API_KEY='YOUR_SECRET'
```
Never put that secret in `index.html`, `app.js`, `manifest.webmanifest`, or any public Git repository.
