# Artiman AI — Offline-first Persian/English PWA

A mobile-first productivity web app for a student learning electric guitar and balancing school, gym, TikTok and personal progress.

## Included
- Persian/English switch with RTL/LTR
- Cyber Aurora dark/light theme
- Home, weekly plan, AI assistant, progress, settings
- Offline-first localStorage persistence
- PWA manifest + service worker
- Fixed school/language/gym time blocks are read-only
- Flexible daily study/guitar/TikTok tasks
- 45 min daily TikTok minimum and 45 min daily guitar target
- Progress tracking + streaks
- JSON export/reset
- Optional secure backend URL for real AI; no API key in client
- Node/Express backend example in `backend/`

## Run locally
Any static HTTP server works. Examples:

### Python
```bash
python -m http.server 8080
```
Then open `http://localhost:8080`.

### GitHub Pages
Upload the project to a repository and enable Pages for the root of the default branch. The site is static and needs no build step.

> Opening `index.html` directly with `file://` works for most UI features, but PWA install/offline caching requires HTTPS or localhost.

## Real AI
Set `Backend URL` in Settings. The client will call:
`POST {backend}/chat`
with JSON:
```json
{"message":"...","context":{"weekId":"...","days":{},"progress":{}}}
```
The backend example never exposes an API key to the browser.

## Safety / privacy
Do not store sensitive personal data. Do not put AI API keys in `app.js`, HTML, or any public/static hosting repository.

## Online AI (phone-only)

A ready Cloudflare Workers AI backend is included in `cloudflare-worker/`. Deploy it from the Cloudflare dashboard, add a Workers AI binding named `AI`, and configure `ALLOWED_ORIGIN`. Then paste the Worker URL into Settings → Backend URL. The app falls back to offline guidance if the backend is missing or unavailable.
