const MODEL = '@cf/meta/llama-3.2-1b-instruct';

const SYSTEM = `You are Artiman AI, a supportive bilingual productivity assistant for a 15-year-old student.
Answer in the same language as the user's message (Persian or English).
Use the supplied schedule/progress context when relevant.
Priorities: school, sleep/rest, study, guitar, gym, TikTok, free time.
Never change fixed school, language-class, or fixed gym blocks when discussing planning.
For gym advice, emphasize technique, gradual progression, recovery, and no maximal lifting.
For TikTok, protect privacy: never encourage sharing full name, school name, exact address, phone number, live location, or other private information.
Do not claim to have capabilities or live information you do not have.
Keep answers practical and age-appropriate.`;

function corsHeaders(origin, allowed) {
  const allow = allowed === '*' ? '*' : (origin === allowed ? origin : 'null');
  return {
    'Access-Control-Allow-Origin': allow,
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Vary': 'Origin',
  };
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get('Origin') || '';
    const allowed = env.ALLOWED_ORIGIN || '*';
    const headers = corsHeaders(origin, allowed);

    if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers });
    if (request.method !== 'POST') return Response.json({ error: 'Use POST /chat' }, { status: 405, headers });
    if (allowed !== '*' && origin !== allowed) return Response.json({ error: 'Origin not allowed' }, { status: 403, headers });

    let body;
    try { body = await request.json(); } catch {
      return Response.json({ error: 'Invalid JSON' }, { status: 400, headers });
    }
    const message = typeof body.message === 'string' ? body.message.trim().slice(0, 3000) : '';
    if (!message) return Response.json({ error: 'Message is required' }, { status: 400, headers });

    const context = body.context && typeof body.context === 'object' ? body.context : {};
    const safeContext = {
      weekId: String(context.weekId || '').slice(0, 20),
      progress: context.progress || {},
      days: context.days || {}
    };

    const prompt = `${SYSTEM}\n\nCURRENT APP CONTEXT (schedule/progress only):\n${JSON.stringify(safeContext)}\n\nUSER MESSAGE:\n${message}`;

    try {
      const result = await env.AI.run(MODEL, {
        prompt,
        max_tokens: 500,
        temperature: 0.5
      });
      const response = result?.response || result?.result?.response || 'AI did not return a response.';
      return Response.json({ response, online: true }, { headers });
    } catch (error) {
      return Response.json({ error: 'AI temporarily unavailable' }, { status: 503, headers });
    }
  }
};
