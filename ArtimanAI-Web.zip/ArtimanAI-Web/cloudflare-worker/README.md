# Artiman AI — Cloudflare Worker backend

This backend uses Cloudflare Workers AI through an AI binding. No AI API key is embedded in the web app.

## Phone-only deployment

1. Create/sign in to a Cloudflare account.
2. Open Workers & Pages → Create application → Create Worker.
3. Give it a name such as `artiman-ai-backend` and deploy the starter Worker.
4. Open the Worker → Edit code. Replace its code with `src/index.js` from this folder.
5. Open Settings → Bindings → Add → Workers AI. Set variable name to `AI`.
6. Open Settings → Variables and Secrets. Add a variable named `ALLOWED_ORIGIN`.
   - During testing you can use `*`.
   - For production, replace `*` with the exact HTTPS origin where the Artiman PWA is hosted, e.g. `https://username.github.io`.
7. Deploy.
8. Copy the Worker URL, e.g. `https://artiman-ai-backend.<subdomain>.workers.dev`.
9. In Artiman AI → Settings → Backend URL, paste that URL. The app automatically calls `/chat`.

## AI model

The Worker uses `@cf/meta/llama-3.2-1b-instruct`. Cloudflare Workers AI currently provides a daily free neuron allocation; usage beyond the free allocation may require a paid plan. Check current pricing before production use.

## Security

The browser never receives an AI provider secret. If you later switch to a third-party AI provider, keep its key as a Cloudflare Worker Secret and never put it in HTML/JS.
